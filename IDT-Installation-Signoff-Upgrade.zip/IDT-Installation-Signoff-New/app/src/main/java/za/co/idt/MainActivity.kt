package za.co.idt
import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.webkit.*
import android.net.Uri

class MainActivity : Activity() {
    private lateinit var web: WebView
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(object {
            @JavascriptInterface fun share(text: String) {
                val i = Intent(Intent.ACTION_SEND)
                i.type = "text/plain"
                i.putExtra(Intent.EXTRA_TEXT, text)
                startActivity(Intent.createChooser(i, "Share report"))
            }
        }, "Android")
        setContentView(web)
        web.loadDataWithBaseURL(null, html(), "text/html", "UTF-8", null)
    }
    private fun html() = """<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>
<style>
body{margin:0;background:#070b10;color:#eaf2f7;font-family:Arial;padding:14px}h1{color:#19e66b;font-size:22px}h2{color:#55aaff}
.card{background:#101923;border:1px solid #244052;border-radius:12px;padding:12px;margin:10px 0}
input,textarea,button{width:100%;box-sizing:border-box;margin:5px 0;padding:11px;border-radius:7px;border:1px solid #39576a;background:#0a1118;color:white}
button{background:#123a50;color:#19e66b;font-weight:bold;border:1px solid #19e66b}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}.small{font-size:12px;color:#9db0bd}
</style></head><body>
<h1>I.D.T. STEELWORKS AND ENGINEERING</h1><div class='small'>Installation Sign-Off • Offline Report</div>
<div class='card'><h2>Report Details</h2>
<input id='client' placeholder='Client name'><input id='site' placeholder='Site / project'><input id='date' type='date'>
<textarea id='notes' placeholder='General notes'></textarea><label>Photos (up to 10)</label><input id='photos' type='file' accept='image/*' multiple><div id='photoPreview'></div></div>
<div id='items'></div>
<div class='card'><h2>Acceptance & Signatures</h2>
<textarea id='accept' placeholder='Acceptance comments'></textarea>
<input id='clientSig' placeholder='Client signature name / confirmation'>
<input id='installerSig' placeholder='Installer signature name / confirmation'>
<canvas id='sig' width='600' height='180' style='width:100%;background:white;border:2px solid #19e66b;border-radius:8px;touch-action:none'></canvas><button onclick='clearSig()'>CLEAR SIGNATURE</button><button onclick='lockSig()'>LOCK SIGNATURE</button><div id='sigState' class='small'>Signature unlocked</div>
<button onclick='saveReport()'>SAVE REPORT LOCALLY</button>
<button onclick='shareReport()'>SHARE REPORT (WhatsApp / Email)</button>
<button onclick='window.print()'>PRINT / SAVE AS PDF</button>
</div>
<div class='small'>Unit 7, Concert Park, Joe Mark's Boulevard, Retreat • 0645558411 • iwardio@idtsteel.co.za</div>
<script>
const wrap=document.getElementById('items');
for(let i=1;i<=10;i++){wrap.innerHTML+=`<div class='card'><h2>Item ${i}</h2>
<input id='item${i}' placeholder='Item / work description'><textarea id='desc${i}' placeholder='Description / notes'></textarea>
<div class='grid'><input id='qty${i}' placeholder='Quantity'><input id='status${i}' placeholder='Status (text)'></div>
<input id='quality${i}' placeholder='Quality / defects / comments'></div>`}
document.getElementById('date').value=new Date().toISOString().slice(0,10);
const canvas=document.getElementById('sig'),ctx=canvas.getContext('2d');let drawing=false,locked=false;ctx.lineWidth=3;ctx.strokeStyle='#111';
function point(e){const r=canvas.getBoundingClientRect();const t=e.touches?e.touches[0]:e;return {x:(t.clientX-r.left)*canvas.width/r.width,y:(t.clientY-r.top)*canvas.height/r.height}}
function start(e){if(locked)return;drawing=true;const q=point(e);ctx.beginPath();ctx.moveTo(q.x,q.y);e.preventDefault()}
function move(e){if(!drawing||locked)return;const q=point(e);ctx.lineTo(q.x,q.y);ctx.stroke();e.preventDefault()}
function end(){drawing=false}['mousedown','touchstart'].forEach(x=>canvas.addEventListener(x,start));['mousemove','touchmove'].forEach(x=>canvas.addEventListener(x,move));['mouseup','mouseleave','touchend'].forEach(x=>canvas.addEventListener(x,end));
function clearSig(){if(!locked)ctx.clearRect(0,0,canvas.width,canvas.height)}function lockSig(){locked=true;document.getElementById('sigState').textContent='Signature locked'}
document.getElementById('photos').addEventListener('change',e=>{const files=[...e.target.files].slice(0,10);const out=document.getElementById('photoPreview');out.innerHTML='';files.forEach(f=>{const img=document.createElement('img');img.src=URL.createObjectURL(f);img.style='width:48%;margin:1%;max-height:130px;object-fit:cover';out.appendChild(img)})});
function val(id){return document.getElementById(id).value}
function report(){let s='IDT INSTALLATION SIGN-OFF\nClient: '+val('client')+'\nSite: '+val('site')+'\nDate: '+val('date')+'\n';
for(let i=1;i<=10;i++)s+='\nITEM '+i+'\n'+val('item'+i)+'\n'+val('desc'+i)+'\nQty: '+val('qty'+i)+'\nStatus: '+val('status'+i)+'\nQuality: '+val('quality'+i)+'\n';
return s+'\nNotes: '+val('notes')+'\nAcceptance: '+val('accept')+'\nClient: '+val('clientSig')+'\nInstaller: '+val('installerSig')}
function saveReport(){localStorage.setItem('idtReport',report());alert('Report saved on this phone.')}
function shareReport(){let s=report();if(window.Android)Android.share(s);else navigator.clipboard.writeText(s).then(()=>alert('Report copied.'))}
</script></body></html>"""
